SupplyGuard KG 工作空间证据包：ws_20260614_024533_46daea15
项目：3CX X_TRADER replay
